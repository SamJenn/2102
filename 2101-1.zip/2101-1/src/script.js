console.clear();
console.log("hello world");

const students = [];

function makeStudent(username,first,last,gradelevel){
  const student = {};
  student.username = username;
  student.first = first;
  student.last = last;
  student.gradelevel = gradelevel;
  return student;
}

students.push(makeStudent("roryleonard","Rory","Leonard","9"));
students.push(makeStudent("SamJennings","Sam","Jennings","10"));
students.push(makeStudent("LuciaLopez","Lucia","Lopez","11"));
students.push(makeStudent("RocketDavis","Rocket","Davis","12"))
students.push(makeStudent("WilliamGross","William","Gross","13"))
students.push(makeStudent("KeeganAtchison","Keegan","Atchison","14"))
students.push(makeStudent("ShayMeseck-Schick","Shay","Meseck-Schick","15"))
students.push(makeStudent("ZoeBishop","Zoe","Bishop","16"))
students.push(makeStudent("GunnisonSweeney","Gunnison","Sweeney","17"))


console.log(students);

function pickStudent(){
  let randomStudentNum = Math.floor(Math.random()*students.length);
  console.log(randomStudentNum);
  let student = students[randomStudentNum];
  console.log(student);
  document.getElementById("picked").textContent = student.first + " " + student.last;
}

pickStudent();

let element = document.getElementById("pickStudent");

element.addEventListener("click",pickStudent);